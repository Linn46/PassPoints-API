# Capturas para el capítulo 3

Las imágenes de `capturas/` se obtuvieron navegando la interfaz local de
PassPoints. Las secciones y pies siguientes son sugerencias; ajusta la
numeración a la estructura final de la tesis.

| Archivo | Sección sugerida | Pie de figura sugerido |
|---|---|---|
| `captura_01_acceso.png` | 3.1 Pantalla de acceso | **Figura 3.1.** Pantalla inicial de autenticación de PassPoints con las opciones de registro e inicio de sesión. |
| `captura_02_seleccion.png` | 3.2 Selección de la contraseña gráfica | **Figura 3.2.** Selección de cinco puntos sobre el fondo «Forest trail» y contador de progreso de la interfaz. |
| `captura_03_respuesta_analisis.png` | 3.3 Respuesta al análisis | **Figura 3.3.** Resultado visible del análisis de una selección de ejemplo sin patrones débiles detectados. |
| `captura_03b_analisis_completo.png` | 3.3 Respuesta al análisis | Captura de página completa que conserva el contexto de la interfaz y la respuesta anterior. |
| `captura_04_validacion_puntos.png` | 3.4 Validación de selección | **Figura 3.4.** Mensaje de validación cuando se intenta colocar dos puntos demasiado próximos durante el registro. |
| `captura_05_respuesta_patron_debil.png` | 3.5 Detección de patrones débiles | **Figura 3.5.** La interfaz muestra la advertencia de puntos agrupados devuelta por el análisis. |
| `captura_06_explicacion_patron.png` | 3.5.1 Explicación al usuario | **Figura 3.6.** Diálogo con la explicación y recomendación asociadas al patrón agrupado. |
| `captura_07_login.png` | 3.6 Inicio de sesión | **Figura 3.7.** Formulario de inicio de sesión con imagen seleccionada y una secuencia de cinco puntos. |
| `captura_08_rechazo_acceso.png` | 3.6.1 Rechazo de credenciales | **Figura 3.8.** Mensaje mostrado después de un intento de acceso con credenciales no registradas; la API respondió HTTP 401. |

## Alcance de las capturas

- Los análisis y las secuencias son demostraciones controladas para documentar
  el comportamiento del sistema; no son resultados de una prueba con
  participantes.
- El intento de inicio de sesión usó la dirección reservada
  `cap3-demo@example.test`, que no identifica a una persona. Solo se hizo una
  consulta de acceso; no se creó ni modificó una cuenta.
- La validación de puntos próximos se genera en la interfaz antes de enviar
  una petición al backend.
- La captura de error 401 muestra la respuesta real del backend y el mensaje
  correspondiente de la interfaz.

## Ejecución de pruebas

La suite se ejecuta desde la raíz del proyecto con:

    .venv/bin/pytest -q --tb=short

Resultado de la última ejecución: **150 passed**, con cuatro advertencias de
deprecación de dependencias/configuración. No hubo pruebas fallidas.
